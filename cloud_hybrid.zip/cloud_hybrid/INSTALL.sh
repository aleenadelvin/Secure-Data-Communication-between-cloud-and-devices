echo "INSTALLING....."
sudo apt-get install  python3-dev
sudo apt-get install python3-pip
sudo pip3 install boto3
sudo pip3 install pillow
sudo pip3 install progress

