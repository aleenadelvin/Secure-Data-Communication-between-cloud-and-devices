python3 src/GUI_main.py
